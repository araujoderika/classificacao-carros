# 📊🚗 Analisando Carros com R

## O que é isso?

Você já reparou que carros mais potentes geralmente bebem mais
gasolina? A gente vai usar o **R** (uma linguagem que adora
números e gráficos) pra provar isso com dados de verdade... bom,
quase verdade, são dados de exemplo! 😄

É como ser um cientista: você pega um monte de números sobre
carros e desenha desenhos (gráficos) pra entender melhor as coisas,
tipo "quanto mais forte o motor, mais gasolina o carro gasta".

## O que tem nesse projeto

- `carros.csv` → uma tabela com potência, consumo e preço de vários carros
- `analise.R` → um script que lê essa tabela, faz contas e desenha gráficos

## Como rodar

1. Instale o R e o RStudio (são grátis)
2. Abra o arquivo `analise.R` no RStudio
3. Clique em "Run" em cada linha (ou aperte Ctrl+Enter) e veja os
   gráficos aparecerem do lado direito da tela!

## O que você vai aprender

- Como ler uma tabela (CSV) no R
- Como calcular médias (ex: "qual a potência média dos carros?")
- Como fazer um gráfico de pontos (scatter plot) pra ver se
  potência e consumo estão relacionados
