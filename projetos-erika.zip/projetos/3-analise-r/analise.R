# 📊 Analisando Carros com R
# Vamos descobrir: carros mais potentes gastam mais gasolina?

# 1. Vamos ler nossa tabela de carros (como abrir um Excel)
carros <- read.csv("carros.csv")

# Vamos dar uma espiada na tabela
print(carros)

# 2. Qual é a potência MÉDIA dos carros? (soma tudo e divide pela quantidade)
potencia_media <- mean(carros$potencia_cv)
cat("Potência média dos carros:", potencia_media, "cv\n")

# 3. Qual é o consumo MÉDIO (quantos km cada carro anda com 1 litro)?
consumo_medio <- mean(carros$consumo_km_l)
cat("Consumo médio:", consumo_medio, "km por litro\n")

# 4. Qual carro é o mais potente?
carro_mais_potente <- carros[which.max(carros$potencia_cv), ]
cat("O carro mais potente é o", carro_mais_potente$modelo, "\n")

# 5. Qual carro é o mais econômico (anda mais longe com 1 litro)?
carro_mais_economico <- carros[which.max(carros$consumo_km_l), ]
cat("O carro mais econômico é o", carro_mais_economico$modelo, "\n")

# 6. Agora o mais legal: vamos desenhar um gráfico!
#    Cada pontinho é um carro. Vamos ver se carros com MAIS potência
#    (eixo x) gastam MENOS km por litro (eixo y) -> ou seja, o ponto
#    desce conforme anda para a direita.
plot(
  carros$potencia_cv, carros$consumo_km_l,
  main = "Potência x Consumo dos Carros",
  xlab = "Potência (cv) - quanto mais forte o motor",
  ylab = "Consumo (km/l) - quanto mais longe anda com 1 litro",
  pch = 19,
  col = "steelblue"
)

# Repare que os carros mais potentes (tipo o Mustang e o 911)
# ficam bem embaixo no gráfico, ou seja, rodam menos km com 1 litro!
# Isso confirma o que a gente imaginava: mais força = mais gasolina.

# Desafio: tente adicionar seus próprios carros no arquivo carros.csv
# e rode o script de novo pra ver como o gráfico muda! 🚀
