-- 🚗 Banco de dados de uma concessionária de carros
-- Aqui a gente cria as "gavetas" (tabelas) e coloca fichas (dados) dentro delas

-- Gaveta dos carros
CREATE TABLE carros (
    id INTEGER PRIMARY KEY,
    marca TEXT,
    modelo TEXT,
    ano INTEGER,
    cor TEXT,
    preco REAL
);

-- Gaveta dos clientes
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY,
    nome TEXT,
    cidade TEXT
);

-- Gaveta das vendas (liga um cliente a um carro que ele comprou)
CREATE TABLE vendas (
    id INTEGER PRIMARY KEY,
    id_cliente INTEGER,
    id_carro INTEGER,
    data_venda TEXT,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id),
    FOREIGN KEY (id_carro) REFERENCES carros(id)
);

-- Colocando carros de exemplo na gaveta
INSERT INTO carros (id, marca, modelo, ano, cor, preco) VALUES
(1, 'Toyota', 'Corolla', 2023, 'prata', 145000),
(2, 'Chevrolet', 'Onix', 2022, 'branco', 82000),
(3, 'Ford', 'Mustang', 2021, 'vermelho', 350000),
(4, 'Volkswagen', 'Gol', 2020, 'preto', 65000),
(5, 'Honda', 'Civic', 2023, 'preto', 155000),
(6, 'Jeep', 'Compass', 2022, 'branco', 180000),
(7, 'Fiat', 'Mobi', 2021, 'vermelho', 58000),
(8, 'BMW', 'X1', 2023, 'cinza', 280000),
(9, 'Hyundai', 'HB20', 2022, 'prata', 75000),
(10, 'Porsche', '911', 2020, 'amarelo', 900000);

-- Colocando clientes de exemplo
INSERT INTO clientes (id, nome, cidade) VALUES
(1, 'Ana Souza', 'Osasco'),
(2, 'Bruno Lima', 'São Paulo'),
(3, 'Carla Dias', 'Barueri'),
(4, 'Diego Alves', 'Osasco'),
(5, 'Erika Silva', 'Campinas');

-- Colocando vendas de exemplo
INSERT INTO vendas (id, id_cliente, id_carro, data_venda) VALUES
(1, 1, 2, '2024-01-10'),
(2, 2, 5, '2024-02-14'),
(3, 3, 9, '2024-03-01'),
(4, 4, 4, '2024-03-20'),
(5, 1, 6, '2024-04-05');
