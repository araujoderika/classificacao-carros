# 🚗🗄️ Banco de Dados: Concessionária de Carros

## O que é um banco de dados?

Imagina uma caixa de gavetas bem organizada. Cada gaveta é uma
**tabela**, e dentro dela tem fichas com informações — tipo uma
ficha de cada carro, com marca, modelo, preço, cor...

Um **banco de dados** é isso: um jeito organizado de guardar
MUITAS informações, pra gente poder achar qualquer coisa rapidinho,
tipo "me mostra todos os carros vermelhos que custam menos de
100 mil reais!"

E o **SQL** é a "língua mágica" que usamos pra conversar com essa
caixa de gavetas e pedir as coisas. 🪄

## O que tem nesse projeto

Criamos um banco de dados fake de uma concessionária, com:

- 🚘 Tabela `carros` (marca, modelo, ano, preço, cor)
- 🙋 Tabela `clientes` (nome, cidade)
- 🧾 Tabela `vendas` (quem comprou qual carro)

## Como usar

1. Instale o **DB Browser for SQLite** (é grátis) ou use a extensão
   SQLite do VS Code
2. Abra o arquivo `concessionaria.sql`
3. Rode ele — isso cria as tabelas e já coloca uns carros de exemplo
4. Abra o arquivo `exercicios.sql` e vá tentando responder as perguntas
5. Se travar, olha o arquivo `respostas.sql` — mas só depois de tentar! 😉

## Arquivos

- `concessionaria.sql` → cria as gavetas (tabelas) e coloca os carros dentro
- `exercicios.sql` → perguntas pra você praticar (do fácil pro difícil)
- `respostas.sql` → as respostas certas, pra conferir depois
