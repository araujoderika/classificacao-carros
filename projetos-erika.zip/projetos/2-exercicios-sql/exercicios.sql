-- 🧠 Exercícios de SQL — Concessionária de Carros
-- Tente escrever a consulta (query) embaixo de cada pergunta.
-- Dica: SELECT = "me mostra", FROM = "de onde", WHERE = "que seja assim"

-- ============================
-- NÍVEL FÁCIL 🟢
-- ============================

-- 1. Mostre todos os carros da tabela


-- 2. Mostre apenas a marca e o modelo de todos os carros


-- 3. Mostre todos os clientes que moram em "Osasco"


-- ============================
-- NÍVEL MÉDIO 🟡
-- ============================

-- 4. Mostre todos os carros que custam menos de 100000


-- 5. Mostre todos os carros da cor "preto" fabricados depois de 2021


-- 6. Mostre os carros ordenados do mais caro para o mais barato


-- 7. Conte quantos carros existem de cada marca
--    (dica: use GROUP BY marca)


-- ============================
-- NÍVEL DIFÍCIL 🔴
-- ============================

-- 8. Mostre o nome do cliente e o modelo do carro que ele comprou
--    (dica: você vai precisar "juntar" 3 tabelas com JOIN:
--     vendas + clientes + carros)


-- 9. Descubra qual foi o carro mais caro já vendido


-- 10. Mostre a marca dos carros e o preço médio de cada marca
--     (dica: use AVG(preco) e GROUP BY marca)
