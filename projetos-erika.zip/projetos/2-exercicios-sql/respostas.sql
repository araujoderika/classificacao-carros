-- ✅ Respostas dos Exercícios — só olhe depois de tentar sozinha!

-- 1. Mostre todos os carros da tabela
SELECT * FROM carros;

-- 2. Mostre apenas a marca e o modelo de todos os carros
SELECT marca, modelo FROM carros;

-- 3. Mostre todos os clientes que moram em "Osasco"
SELECT * FROM clientes WHERE cidade = 'Osasco';

-- 4. Mostre todos os carros que custam menos de 100000
SELECT * FROM carros WHERE preco < 100000;

-- 5. Mostre todos os carros da cor "preto" fabricados depois de 2021
SELECT * FROM carros WHERE cor = 'preto' AND ano > 2021;

-- 6. Mostre os carros ordenados do mais caro para o mais barato
SELECT * FROM carros ORDER BY preco DESC;

-- 7. Conte quantos carros existem de cada marca
SELECT marca, COUNT(*) AS quantidade
FROM carros
GROUP BY marca;

-- 8. Mostre o nome do cliente e o modelo do carro que ele comprou
SELECT clientes.nome, carros.modelo
FROM vendas
JOIN clientes ON vendas.id_cliente = clientes.id
JOIN carros ON vendas.id_carro = carros.id;

-- 9. Descubra qual foi o carro mais caro já vendido
SELECT carros.modelo, carros.preco
FROM vendas
JOIN carros ON vendas.id_carro = carros.id
ORDER BY carros.preco DESC
LIMIT 1;

-- 10. Mostre a marca dos carros e o preço médio de cada marca
SELECT marca, AVG(preco) AS preco_medio
FROM carros
GROUP BY marca;
