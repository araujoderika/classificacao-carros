# 📓 Minhas Anotações de Estudos

## Pra que serve isso?

Sabe quando você aprende uma coisa nova e depois esquece? Esse
repositório é como um **caderno mágico** que guarda tudo que você
foi aprendendo sobre Banco de Dados e Inteligência Artificial —
assim, quando esquecer, é só vir aqui reler! 📖✨

Também serve pra mostrar pras pessoas (tipo em uma entrevista de
emprego) tudo que você já estudou.

## Como está organizado

```
anotacoes-estudos/
├── banco-de-dados/
│   └── 01-modelagem-de-dados.md
├── inteligencia-artificial/
│   └── 01-classificacao-de-dados.md
└── projetos-com-carros/
    └── ideias.md
```

Cada assunto tem sua própria pasta, e cada anotação é um arquivinho
separado — assim fica fácil de achar depois!

## Como usar

1. Toda vez que aprender algo novo, crie um arquivo `.md` novo
   (ou edite um que já existe)
2. Escreva com suas próprias palavras — isso ajuda a fixar melhor!
3. Coloque exemplos, se possível
4. Suba pro GitHub (`git add`, `git commit`, `git push`) pra guardar
   pra sempre

## Dica de ouro 💡

Não precisa ser bonito nem perfeito. O importante é registrar o
que você aprendeu, do jeitinho que fizer sentido pra você.
