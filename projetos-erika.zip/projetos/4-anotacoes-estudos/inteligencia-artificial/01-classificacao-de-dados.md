# 🤖 Classificação e Rotulagem de Dados — Anotações

## O que é "rotulagem de dados"?

É colocar uma "etiqueta" em cada exemplo, pra ensinar o computador.
Tipo: você mostra uma foto de um carro esportivo e escreve do lado
"isso é ESPORTIVO" — essa etiqueta se chama **rótulo (label)**.

## O que é "classificação"?

É quando o computador aprende, a partir de vários exemplos com
rótulo, a **adivinhar o rótulo certo** de coisas novas que ele
nunca viu.

## Exemplo com carros 🚗

| Potência | Velocidade Máx | Rótulo (tipo) |
|----------|-----------------|---------------|
| 450 cv   | 300 km/h        | Esportivo     |
| 120 cv   | 170 km/h        | Sedan         |
| 250 cv   | 190 km/h        | SUV           |

Depois de ver muitos exemplos assim, o computador consegue
adivinhar o tipo de um carro novo, só olhando a potência e a
velocidade dele!

## Palavras novas que aprendi

- **Dataset:** o conjunto de exemplos usados pra ensinar o computador
- **Rótulo (label):** a resposta certa de cada exemplo
- **Modelo:** o "cérebro" treinado que aprendeu a adivinhar
- **Treino e teste:** separamos uma parte dos exemplos pra ENSINAR
  e outra parte pra TESTAR se ele aprendeu direito

## Onde já pratiquei isso

- Projeto `classificacao-carros` (aqui no meu GitHub) — fiz um
  programa que adivinha o tipo do carro usando Python!
