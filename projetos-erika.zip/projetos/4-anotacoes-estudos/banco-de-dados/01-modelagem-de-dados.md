# 🗄️ Modelagem de Dados — Anotações

## O que é modelagem de dados?

É como desenhar a "planta de uma casa" antes de construir. Antes
de criar um banco de dados de verdade, a gente desenha como as
tabelas vão se conectar.

## Exemplo com carros 🚗

Imagina que eu quero guardar informações de uma concessionária:

- Tabela **carros**: id, marca, modelo, preço
- Tabela **clientes**: id, nome, cidade
- Tabela **vendas**: liga um cliente a um carro que ele comprou

A tabela `vendas` é o que chamamos de "tabela de ligação" — ela
serve pra conectar duas outras tabelas (clientes e carros).

## Palavras novas que aprendi

- **Chave primária (Primary Key):** o "RG" de cada linha da tabela,
  um número que nunca se repete
- **Chave estrangeira (Foreign Key):** quando uma tabela "aponta"
  pra outra, tipo dizendo "esse cliente comprou ESSE carro aqui"
- **Normalização:** organizar as tabelas pra não repetir
  informação à toa

## Dúvidas que ainda tenho

- (escreva aqui as coisas que ainda não entendeu 100%, pra
  perguntar pro professor ou pesquisar depois)
