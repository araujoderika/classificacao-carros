# 💡 Ideias de Projetos Futuros (tema: carros)

Lista de ideias pra praticar mais Banco de Dados e IA, sempre com
carros no meio:

- [ ] Classificar carros por **faixa de preço** (popular, médio, luxo)
- [ ] Prever o **preço de um carro usado** com base na idade e km rodados
- [ ] Montar um banco de dados de **oficina mecânica** (clientes,
      serviços, peças)
- [ ] Rotular fotos de carros por **cor** (dataset de imagens)
- [ ] Criar um dashboard mostrando **vendas de carros por mês**
- [ ] Analisar quais **marcas de carro** aparecem mais em anúncios
      de venda online

Vá marcando com um ✅ (troque `[ ]` por `[x]`) conforme for
terminando cada projeto!
